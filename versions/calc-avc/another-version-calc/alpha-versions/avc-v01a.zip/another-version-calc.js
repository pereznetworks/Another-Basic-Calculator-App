$(document).ready(function(){

  var sum = 0;
  var numValue1 = 0;
  var numValue2 = 0;
  var newNumber = "";
  var prevNumber = "";
  var answer = "";
  var operator = "";

  var totaldiv = $("#total");
  totaldiv.text("0");

  	var testNumLength = function(number) {
          if (number.length > 9) {
              totaldiv.text(number.substr(number.length-9,9));
              if (number.length > 15) {
                  number = "";
                  totaldiv.text("Err");
              }
          }
      };

    $('#clear').click(function(){
        newNumber = '';
        totaldiv.text('0');
        });

    $('#clearall').click(function(){
        newNumber = '';
        prevNumber = '';
        totaldiv.text('0');
        });

    $("#numbers > a").not("#clear,#clearall").click(function(){
    		newNumber += $(this).text();
    		totaldiv.text(newNumber);
    		testNumLength(newNumber);
        console.log("newNumber = " + newNumber);
    });

    $("#operators > a").not("#equals").click(function(){
    		operator = $(this).text();
    		prevNumber = newNumber;
    		newNumber = "";
        console.log("prevNumber = " + prevNumber);
        console.log("math operator = " + operator);
    });

    $('#equals').click(function () {

        console.log("running equals..");
        console.log("prevNumber: " + prevNumber + " and newNumber:" + newNumber );
        numValue2 = parseInt(newNumber, 10);
        numValue1 = parseInt(prevNumber, 10);

        if ( isNaN(parseInt(prevNumber, 10)) ) {
            numValue1 = 0;
        }

        console.log(numValue2);
        console.log(operator);
        console.log(numValue1);

        if (operator === "+") {

            sum = sum + (numValue1 + numValue2);
            console.log("sum is: " + sum);

          } else if ( operator === "-") {

            sum = sum - (numValue1 + numValue2);
            console.log("sum is: " + sum);

          } else if ( operator === "/") {

            sum = sum / (numValue1 + numValue2);
            console.log("sum is: " + sum);

          } else if ( operator === "*") {

            sum = sum * (numValue1 + numValue2);
            console.log("sum is: " + sum);

          }

        answer = sum.toString(10);
        console.log(answer);
        totaldiv.text( answer );
        testNumLength( answer );

        newNumber = "";
        prevNumber = "";

        });
});
